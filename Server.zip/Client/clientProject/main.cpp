#include "mainwindow.h"
#include <QTcpSocket>
#include <QApplication>
#include "clientproject.h"
int main(int argc, char *argv[])
{

    QApplication a(argc, argv);

    clientProject *newobj=new clientProject();

    return a.exec();
}
