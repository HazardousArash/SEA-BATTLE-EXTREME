#include "serverproject.h"
#include "ui_serverproject.h"

serverProject::serverProject(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::serverProject)
{
    ui->setupUi(this);
    myServer = new QTcpServer(this);
    myServer->listen(QHostAddress("127.0.0.1"), 1025);
    if (!myServer->isListening()) {
        qDebug() << "not listening..";
    } else {
        qDebug() << "listening..";
        connect(myServer, &QTcpServer::newConnection, this, &serverProject::newConnectionSlot);
    }

    // Initialize boards with sample data
    player1Board = QVector<QVector<int>>(10, QVector<int>(10, 0));
    player2Board = QVector<QVector<int>>(10, QVector<int>(10, 0));

    // Sample data for player boards
}

serverProject::~serverProject()
{
    delete ui;
}

void serverProject::newConnectionSlot()
{
    mySocket = myServer->nextPendingConnection();
    qDebug() << "New connected Device: " << mySocket->socketDescriptor();
    connect(mySocket, &QTcpSocket::connected, this, &serverProject::connectedToServer);
    connect(mySocket, &QTcpSocket::bytesWritten, this, &serverProject::writingData);
    connect(mySocket, &QTcpSocket::readyRead, this, &serverProject::readingData);
    connect(mySocket, &QTcpSocket::disconnected, this, &serverProject::disconnectedFromServer);
    sendBoards();
}

void serverProject::writingData()
{
    qDebug() << "written successfully\n";
}

void serverProject::disconnectedFromServer()
{
    qDebug() << "Connection lost\n";
}

void serverProject::connectedToServer()
{
    qDebug() << "Connected Successfully\n";
    mySocket->write("Salam\n");
}

void serverProject::readingData()
{
    qDebug() << "Data received\n";
    qDebug() << "Received data: " << mySocket->readAll();
    sendBoards();
}

void serverProject::sendBoards()
{
    QByteArray serializedData;
    QDataStream stream(&serializedData, QIODevice::WriteOnly);
    stream << player1Board << player2Board;
    mySocket->write(serializedData);
}
