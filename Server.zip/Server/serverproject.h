#ifndef SERVERPROJECT_H
#define SERVERPROJECT_H

#include <QWidget>
#include <QTcpServer>
#include <QTcpSocket>
#include <QVector>
#include <vector>

QT_BEGIN_NAMESPACE
namespace Ui { class serverProject; }
QT_END_NAMESPACE

class serverProject : public QWidget
{
    Q_OBJECT

public:
    serverProject(QWidget *parent = nullptr);
    ~serverProject();

private slots:
    void newConnectionSlot();
    void connectedToServer();
    void writingData();
    void disconnectedFromServer();
    void readingData();

private:
    void sendBoards();
    Ui::serverProject *ui;
    QTcpServer *myServer;
    QTcpSocket *mySocket;
    QVector<QVector<int>> player1Board;
    QVector<QVector<int>> player2Board;
    std::vector<std::vector<int>> serverBoard;
    std::vector<std::vector<int>> enemyBoard;
};
#endif // SERVERPROJECT_H
