ifndef DRAGGABLESHIP_H
#define DRAGGABLESHIP_H


class DraggableShip
{
public:
    DraggableShip();
};

#endif // DRAGGABLESHIP_H
