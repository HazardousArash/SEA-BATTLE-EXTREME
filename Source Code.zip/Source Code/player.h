#ifndef PLAYER_H
#define PLAYER_H

class Player
{
private:
    bool isWinner;
    bool turn;

public:
Player();
};

#endif // PLAYER_H
