#include "humanplayer.h"

HumanPlayer::HumanPlayer() {}
