#include "computerplayer.h"
#include <QRandomGenerator>
#include "Board.h"
#include <qdebug.h>

ComputerPlayer::ComputerPlayer():difficulty(1),name("NULL"),level(1),code("NULL"){}



