#ifndef GAME_H
#define GAME_H

void runGame();

#endif // GAME_H
