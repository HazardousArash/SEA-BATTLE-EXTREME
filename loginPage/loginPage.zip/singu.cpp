#include "singu.h"
#include "ui_singu.h"
#include "mainwindow.h"
#include <QSqlDatabase>
#include <QDebug>
#include <QSqlQuery>
#include <QString>
#include <QErrorMessage>
#include <QCryptographicHash>

singU::singU(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::singU)
{
    ui->setupUi(this);
}

singU::~singU()
{
    delete ui;
}
QString hashPasswordAgain(const QString& password) {
    QByteArray passwordBytes = password.toUtf8();
    QByteArray hash = QCryptographicHash::hash(passwordBytes, QCryptographicHash::Sha256);
    return hash.toHex();
}

void singU::on_pushButton_clicked()
{
         QErrorMessage* errorDialog = new QErrorMessage(this);
    if(ui->lineEdit_3==NULL||ui->lineEdit_4==NULL||ui->lineEdit_5==NULL||ui->userLine==NULL||ui->passLine==NULL){
        qDebug()<<"Please give us all the detail!";
         errorDialog->showMessage("Please fill everything");
    }
    else{
        QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
        db.setDatabaseName("G:\\oldDesktop\\programing\\newS\\UNI\\402-403-AP\\QTFiles\\loginPage\\newDB.db");
        if (!db.open()) {
            qDebug() << "Error opening database: ";
        }
        QSqlQuery insertQuery;
        insertQuery.prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
        QString userPass=ui->passLine->text();
        userPass=hashPasswordAgain(userPass);

        insertQuery.bindValue(":username", ui->userLine->text());
        insertQuery.bindValue(":password", userPass);

        if (insertQuery.exec()) {

            qDebug() << "Data inserted successfully!";
errorDialog->showMessage("Sign up was successful");
        } else {
            qDebug() << "Error inserting data: ";
            errorDialog->showMessage("Sign up failed");
        }
    }

}


void singU::on_pushButton_2_clicked()
{
    MainWindow *newwindow=new MainWindow();
    this->close();
    newwindow->show();
}

