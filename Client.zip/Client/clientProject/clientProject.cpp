#include "clientProject.h"
#include <QDataStream>
#include <QDebug>

clientProject::clientProject(QWidget *parent)
    : QWidget(parent),
    socket(new QTcpSocket(this))
{
    connect(socket, &QTcpSocket::connected, this, &clientProject::onConnected);
    connect(socket, &QTcpSocket::readyRead, this, &clientProject::onReadyRead);
    connect(socket, &QTcpSocket::disconnected, this, &clientProject::onDisconnected);

    socket->connectToHost("127.0.0.1", 1025);
}

clientProject::~clientProject()
{
    delete socket;
}

void clientProject::onConnected()
{
    qDebug() << "Connected to server.";
    sendBoards();
}

void clientProject::onReadyRead()
{
    QByteArray receivedData = socket->readAll();
    qDebug() << "Data received";
    processReceivedData(receivedData);
}

void clientProject::onSendData()
{
    qDebug() << "Sending data to server.";
    // Add any data you want to send to the server here
}

void clientProject::onDisconnected()
{
    qDebug() << "Disconnected from server.";
}

void clientProject::processReceivedData(const QByteArray& data)
{
    QDataStream stream(data);
    QVector<QVector<int>> player1Board, player2Board;
    stream >> player1Board >> player2Board;

    qDebug() << "Received player 1 board:";
    for (const auto& row : player1Board) {
        qDebug() << row;
    }

    qDebug() << "Received player 2 board:";
    for (const auto& row : player2Board) {
        qDebug() << row;
    }

    // Convert QVector<QVector<int>> to std::vector<std::vector<int>>
    std::vector<std::vector<int>> stdPlayer1Board, stdPlayer2Board;

    for (const auto& row : player1Board) {
        std::vector<int> stdRow;
        for (const auto& cell : row) {
            stdRow.push_back(cell);
        }
        stdPlayer1Board.push_back(stdRow);
    }

    for (const auto& row : player2Board) {
        std::vector<int> stdRow;
        for (const auto& cell : row) {
            stdRow.push_back(cell);
        }
        stdPlayer2Board.push_back(stdRow);
    }

    // Debug output for std::vector boards
    qDebug() << "Converted std::vector player 1 board:";
    for (const auto& row : stdPlayer1Board) {
        QString rowString;
        for (const auto& cell : row) {
            rowString += QString::number(cell) + " ";
        }
        qDebug() << rowString;
    }

    qDebug() << "Converted std::vector player 2 board:";
    for (const auto& row : stdPlayer2Board) {
        QString rowString;
        for (const auto& cell : row) {
            rowString += QString::number(cell) + " ";
        }
        qDebug() << rowString;
    }
}

void clientProject::sendBoards()
{
    QVector<QVector<int>> player1Board(10, QVector<int>(10, 0)); // Initialize 10x10 vector
    QVector<QVector<int>> player2Board(10, QVector<int>(10, 0)); // Initialize 10x10 vector
    QByteArray serializedData;
    QDataStream stream(&serializedData, QIODevice::WriteOnly);
    stream << player1Board << player2Board;
    socket->write(serializedData);
}
